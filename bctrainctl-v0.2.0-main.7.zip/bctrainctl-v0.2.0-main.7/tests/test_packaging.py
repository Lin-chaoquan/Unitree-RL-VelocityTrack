"""Tests for gitignore-style filtering in core.packaging."""

from __future__ import annotations

import os
import tarfile
from pathlib import Path

import pytest

from bctrainctl.core.packaging import package_project


def _build_tree(root: Path, files: list[str]) -> None:
    for rel in files:
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("x", encoding="utf-8")


def _packaged_files(project: Path, **kwargs) -> set[str]:
    result = package_project(
        project_path=project,
        job_name="test",
        exclude=kwargs.get("exclude", []),
        use_gitignore=kwargs.get("use_gitignore", False),
        gitignore_include=kwargs.get("gitignore_include", []),
    )
    try:
        with tarfile.open(result.package_path) as archive:
            return {member.name for member in archive.getmembers() if member.isfile()}
    finally:
        os.unlink(result.package_path)


@pytest.fixture()
def project(tmp_path: Path) -> Path:
    _build_tree(
        tmp_path,
        [
            "a.py",
            "b.so",
            "keep.txt",
            "src/main.py",
            "src/x/data.bin",
            "src/x/keep.bin",
            "deep/nested/x/data.bin",
            "deep/x/file.log",
            "build/weights/model.pt",
            "build/tmp/junk.o",
            "logs/run.log",
            "logs/keep.log",
            ".git/config",
            "node_modules/p/index.js",
            "__pycache__/c.pyc",
            "outputs/result.txt",
        ],
    )
    return tmp_path


def test_default_excludes_are_always_pruned(project: Path) -> None:
    files = _packaged_files(project)
    assert not any(name.startswith((".git/", "node_modules/", "__pycache__/", "outputs/")) for name in files)
    assert "a.py" in files


def test_double_star_directory_glob(project: Path) -> None:
    (project / ".gitignore").write_text("**/x/*\n", encoding="utf-8")
    files = _packaged_files(project, use_gitignore=True)
    # Every direct child of any `x/` directory at any depth is excluded.
    assert "src/x/data.bin" not in files
    assert "src/x/keep.bin" not in files
    assert "deep/nested/x/data.bin" not in files
    assert "deep/x/file.log" not in files
    assert "src/main.py" in files


def test_negation_inside_gitignore_reincludes_consistently(project: Path) -> None:
    (project / ".gitignore").write_text("logs/\n!logs/keep.log\n", encoding="utf-8")
    files = _packaged_files(project, use_gitignore=True)
    assert "logs/keep.log" in files
    assert "logs/run.log" not in files
    # Adding unrelated include rules must not change the negation outcome.
    files_with_includes = _packaged_files(
        project, use_gitignore=True, gitignore_include=["**/keep.bin"]
    )
    assert "logs/keep.log" in files_with_includes


def test_glob_star_idiom_with_negation(project: Path) -> None:
    (project / ".gitignore").write_text("logs/*\n!logs/keep.log\n", encoding="utf-8")
    files = _packaged_files(project, use_gitignore=True)
    assert "logs/keep.log" in files
    assert "logs/run.log" not in files


def test_gitignore_include_reincludes_excluded_subtree(project: Path) -> None:
    (project / ".gitignore").write_text("build/\n", encoding="utf-8")
    files = _packaged_files(
        project, use_gitignore=True, gitignore_include=["build/weights"]
    )
    assert "build/weights/model.pt" in files
    assert "build/tmp/junk.o" not in files


def test_extension_and_name_patterns(project: Path) -> None:
    files = _packaged_files(project, exclude=["*.so"])
    assert "b.so" not in files
    assert "a.py" in files
